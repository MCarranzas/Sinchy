<table>
    <thead>
        <tr>
            <th colspan="2">LIQUIDACION <?php echo e($liquidacion->numero_documento); ?></th>
        </tr>
    </thead>
    <tbody>
        <tr><td>Numero de documento</td><td><?php echo e($liquidacion->numero_documento); ?></td></tr>
        <tr><td>Codigo de formulario</td><td><?php echo e($liquidacion->codigo_formulario); ?></td></tr>
        <tr><td>Ejercicio</td><td><?php echo e($liquidacion->ejercicio); ?></td></tr>
        <tr><td>Fecha de transaccion</td><td><?php echo e($liquidacion->fecha_transaccion?->format('d/m/Y')); ?></td></tr>
        <tr><td>Estado</td><td><?php echo e($liquidacion->estado->etiqueta()); ?></td></tr>
        <tr><td>Fecha de registro</td><td><?php echo e($liquidacion->fecha_registro?->format('d/m/Y H:i')); ?></td></tr>
        <tr><td>Registrado por</td><td><?php echo e($liquidacion->registro?->nombre_completo); ?></td></tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="2">COMPRADOR</th>
        </tr>
    </thead>
    <tbody>
        <tr><td>Razon social</td><td><?php echo e($liquidacion->comprador_razon_social); ?></td></tr>
        <tr><td>NIM</td><td><?php echo e($liquidacion->comprador_nim); ?></td></tr>
        <tr><td>NIT</td><td><?php echo e($liquidacion->comprador_nit); ?></td></tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="2">VENDEDOR</th>
        </tr>
    </thead>
    <tbody>
        <tr><td>Nombre</td><td><?php echo e($liquidacion->vendedor_nombre); ?></td></tr>
        <tr><td>CI</td><td><?php echo e($liquidacion->vendedor_ci); ?></td></tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="2">PROCEDENCIA</th>
        </tr>
    </thead>
    <tbody>
        <tr><td>Area minera</td><td><?php echo e($liquidacion->nombre_area_minera); ?></td></tr>
        <tr><td>Titular del derecho minero</td><td><?php echo e($liquidacion->titular_derecho_minero); ?></td></tr>
        <tr><td>Pajata AJAM</td><td><?php echo e($liquidacion->codigo_ajam_patente); ?></td></tr>
        <tr><td>Departamento</td><td><?php echo e($liquidacion->departamento_nombre); ?></td></tr>
        <tr><td>Provincia</td><td><?php echo e($liquidacion->provincia_nombre); ?></td></tr>
        <tr><td>Municipio</td><td><?php echo e($liquidacion->municipio_nombre); ?> (<?php echo e($liquidacion->codigo_municipio); ?>)</td></tr>
        <tr><td>Localidad</td><td><?php echo e($liquidacion->localidad_nombre); ?></td></tr>
        <tr><td>Presentacion del mineral</td><td><?php echo e($liquidacion->presentacion_nombre); ?></td></tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="2">CALCULO</th>
        </tr>
    </thead>
    <tbody>
        <tr><td>Peso en gramos</td><td><?php echo e(number_format((float) $liquidacion->peso_gramos, 2, ',', '.')); ?></td></tr>
        <tr><td>Ley pagable</td><td><?php echo e(number_format((float) $liquidacion->ley_pagable * 100, 2, ',', '.')); ?> %</td></tr>
        <tr><td>Tipo de cambio Bs/$</td><td><?php echo e(number_format((float) $liquidacion->tipo_cambio, 2, ',', '.')); ?></td></tr>
        <tr><td>Cotizacion USD/oz t</td><td><?php echo e(number_format((float) $liquidacion->cotizacion_usd_oz_t, 2, ',', '.')); ?></td></tr>
        <tr><td>Aporte caja de salud</td><td><?php echo e($liquidacion->aplica_caja_salud ? 'SI' : 'NO'); ?></td></tr>
        <tr><td>Peso fino (g)</td><td><?php echo e(number_format((float) $liquidacion->peso_fino_gramos, 2, ',', '.')); ?></td></tr>
        <tr><td>Valor USD/g</td><td><?php echo e(number_format((float) $liquidacion->valor_usd_gramo, 2, ',', '.')); ?></td></tr>
        <tr><td>Valor bruto Bs</td><td><?php echo e(number_format((float) $liquidacion->valor_bruto_bs, 2, ',', '.')); ?></td></tr>
        <tr><td>Aporte caja salud Bs</td><td><?php echo e(number_format((float) $liquidacion->aporte_caja_salud_bs, 2, ',', '.')); ?></td></tr>
        <tr><td>Total deducciones Bs</td><td><?php echo e(number_format((float) $liquidacion->total_deducciones_bs, 2, ',', '.')); ?></td></tr>
        <tr><td>VALOR NETO Bs</td><td><?php echo e(number_format((float) $liquidacion->valor_neto_bs, 2, ',', '.')); ?></td></tr>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="2">HISTORIAL DE ESTADOS</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $liquidacion->historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($movimiento->created_at?->format('d/m/Y H:i')); ?></td>
                <td>
                    <?php echo e($movimiento->estado_anterior?->etiqueta() ?? '(inicio)'); ?>

                    &rarr;
                    <?php echo e($movimiento->estado_nuevo->etiqueta()); ?>

                    -
                    <?php echo e($movimiento->usuario?->username ?? $movimiento->usuario_nombre); ?>

                    <?php if($movimiento->comentario): ?>
                        (<?php echo e($movimiento->comentario); ?>)
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="2">Sin movimientos</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Observaciones: <?php echo e($liquidacion->observaciones ?: '-'); ?></td>
        </tr>
    </tbody>
</table>
<?php /**PATH C:\marioc\webs_figma\Sinchy\sinchy-api\resources\views/liquidaciones/excel.blade.php ENDPATH**/ ?>