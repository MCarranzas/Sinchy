<table>
    <thead>
        <tr>
            <th>Numero</th>
            <th>Fecha</th>
            <th>Estado</th>
            <th>Vendedor</th>
            <th>Municipio</th>
            <th>Mineral</th>
            <th>Peso g</th>
            <th>Peso fino g</th>
            <th>Bruto Bs</th>
            <th>Aportes Bs</th>
            <th>Deducciones Bs</th>
            <th>Neto Bs</th>
            <th>Registrado por</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $liquidaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liquidacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($liquidacion->numero_documento); ?></td>
                <td><?php echo e($liquidacion->fecha_transaccion?->format('d/m/Y')); ?></td>
                <td><?php echo e($liquidacion->estado->etiqueta()); ?></td>
                <td><?php echo e($liquidacion->vendedor_nombre); ?></td>
                <td><?php echo e($liquidacion->municipio_nombre); ?></td>
                <td><?php echo e($liquidacion->presentacion_nombre); ?></td>
                <td><?php echo e(number_format((float) $liquidacion->peso_gramos, 2, ',', '.')); ?></td>
                <td><?php echo e(number_format((float) $liquidacion->peso_fino_gramos, 2, ',', '.')); ?></td>
                <td><?php echo e(number_format((float) $liquidacion->valor_bruto_bs, 2, ',', '.')); ?></td>
                <td><?php echo e(number_format((float) $liquidacion->aporte_caja_salud_bs, 2, ',', '.')); ?></td>
                <td><?php echo e(number_format((float) $liquidacion->total_deducciones_bs, 2, ',', '.')); ?></td>
                <td><?php echo e(number_format((float) $liquidacion->valor_neto_bs, 2, ',', '.')); ?></td>
                <td><?php echo e($liquidacion->registro?->username); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th colspan="7">TOTALES (<?php echo e($liquidaciones->count()); ?> liquidaciones)</th>
            <th><?php echo e(number_format((float) $liquidaciones->sum('peso_fino_gramos'), 2, ',', '.')); ?></th>
            <th><?php echo e(number_format((float) $liquidaciones->sum('valor_bruto_bs'), 2, ',', '.')); ?></th>
            <th><?php echo e(number_format((float) $liquidaciones->sum('aporte_caja_salud_bs'), 2, ',', '.')); ?></th>
            <th><?php echo e(number_format((float) $liquidaciones->sum('total_deducciones_bs'), 2, ',', '.')); ?></th>
            <th><?php echo e(number_format((float) $liquidaciones->sum('valor_neto_bs'), 2, ',', '.')); ?></th>
            <th></th>
        </tr>
    </tfoot>
</table>
<?php /**PATH C:\marioc\webs_figma\Sinchy\sinchy-api\resources\views/liquidaciones/excel-reporte.blade.php ENDPATH**/ ?>